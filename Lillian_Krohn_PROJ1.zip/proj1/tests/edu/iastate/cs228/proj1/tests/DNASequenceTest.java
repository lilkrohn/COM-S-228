package edu.iastate.cs228.proj1.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.runners.MethodSorters;

import edu.iastate.cs228.proj1.DNASequence;
import org.junit.FixMethodOrder;

/**
 * @author Lillian Krohn
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class DNASequenceTest {

	String testString;
	DNASequence testDNA;
	char[] testSeqVals = { 'x', 'y', 'z' };

	/**
	 * checks that the exception is thrown
	 */
	@Test(expected = IllegalArgumentException.class)
	public void InvalidSequenceTest() {
		String probst2 = new String("TDG");
		DNASequence dnaseqobj = new DNASequence(probst2.toCharArray());
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest() {
		assertEquals(testString, testDNA);
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest2() {
		testString = "ccgtagct";
		testDNA = new DNASequence(testString.toCharArray());
		assertEquals(true, testDNA.equals(testDNA));
	}

	/**
	 * tests for an invalid letter
	 */
	@Test
	public void isValidLetterTest() {
		testString = "agTcAGTcA";
		testDNA = new DNASequence(testString.toCharArray());
		assertEquals(true, testDNA.isValidLetter('T'));
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest() {
		char[] testChar = { 'a', 'c', 't', 'g' };
		testDNA = new DNASequence(testChar);
		assertEquals(4, testDNA.seqLength());
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest2() {
		char[] testChar = { 'a', 'c', 't', 'g' };
		testDNA = new DNASequence(testChar);
		assertArrayEquals(testChar, testDNA.getSeq());
	}

}
