package edu.iastate.cs228.proj1.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import java.util.Arrays;

import org.junit.runners.MethodSorters;

import edu.iastate.cs228.proj1.Sequence;

import edu.iastate.cs228.proj1.CodingDNASequence;
import edu.iastate.cs228.proj1.DNASequence;
import edu.iastate.cs228.proj1.ProteinSequence;

import org.junit.Before;
import org.junit.FixMethodOrder;

/**
 * @author Lillian Krohn
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class CodingDNASequenceTest {

	String testString;
	CodingDNASequence testCodeSeq;
	char[] testSeqVals = { 'a', 't', 'g' };

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest() {
		assertEquals(testString, testCodeSeq);
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest2() {
		testString = "atgtagat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(false, testCodeSeq.equals(testString));
	}

	/**
	 * tests for a valid letter
	 */
	@Test
	public void isValidLetterTest() {
		testString = "atgatgatg";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(true, testCodeSeq.isValidLetter('g'));

	}

	/**
	 * tests for an invalid letter
	 */
	@Test
	public void isValidLetterTest2() {
		testString = "atgatgggat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(false, testCodeSeq.isValidLetter('$'));
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest() {
		char[] testChar = { 'a', 't', 'g', 't' };
		testCodeSeq = new CodingDNASequence(testChar);
		assertEquals(4, testCodeSeq.seqLength());
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest2() {
		char[] testChar = { 'a', 't', 'g', 'a' };
		testCodeSeq = new CodingDNASequence(testChar);
		assertArrayEquals(testChar, testCodeSeq.getSeq());
	}

	/**
	 * tests the toString method
	 */
	@Test
	public void toStringTest() {
		testString = "atgggtat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(testString, testCodeSeq.toString());
	}

	/**
	 * tests the chechStartCodon method
	 */
	@Test
	public void checkStartCodonTest() {
		testString = "atgATGgat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(true, testCodeSeq.checkStartCodon());
	}

	/**
	 * tests the chechStartCodon method
	 */
	@Test
	public void checkStartCodonTest2() {
		testString = "at";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(false, testCodeSeq.checkStartCodon());
	}

	/**
	 * tests the chechStartCodon method
	 */
	@Test
	public void checkStartCodonTest3() {
		testString = "gat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		assertEquals(false, testCodeSeq.checkStartCodon());
	}

	/**
	 * checks the translate method
	 */
	@Test
	public void translateTest() {
		testString = "gat";
		testCodeSeq = new CodingDNASequence(testString.toCharArray());
		testCodeSeq.translate();
	}

}
