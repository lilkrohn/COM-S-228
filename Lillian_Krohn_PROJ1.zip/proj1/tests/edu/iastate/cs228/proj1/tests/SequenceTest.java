package edu.iastate.cs228.proj1.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.runners.MethodSorters;

import edu.iastate.cs228.proj1.Sequence;

import org.junit.Assert;

import org.junit.FixMethodOrder;

/**
 * @author Lillian Krohn
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class SequenceTest {

	String testString;
	Sequence testSeq;
	//char[] testSeqVals = { 'x', 'y', 'z' };

	/**
	 * checks that the exception is thrown
	 */
	@Test(expected = IllegalArgumentException.class)
	public void InvalidSequenceTest() {
		String probst = new String("T$G");
		Sequence seqobj = new Sequence(probst.toCharArray());
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest() {
		assertEquals(testString, testSeq);
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest2() {
		testString = "abcdefgh";
		testSeq = new Sequence(testString.toCharArray());
		assertEquals(false, testSeq.equals(testString));
	}

	/**
	 * tests for a valid letter
	 */
	@Test
	public void isValidLetterTest() {
		testString = "abcd";
		testSeq = new Sequence(testString.toCharArray());
		assertEquals(true, testSeq.isValidLetter('a'));

	}

	/**
	 * tests for an invalid letter
	 */
	@Test
	public void isValidLetterTest2() {
		testString = "abcd";
		testSeq = new Sequence(testString.toCharArray());
		assertEquals(false, testSeq.isValidLetter('$'));
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest() {
		char[] testChar = { 'h', 'i', 'j', 'k' };
		testSeq = new Sequence(testChar);
		assertEquals(4, testSeq.seqLength());
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest2() {
		char[] testChar = { 'h', 'i', 'j', 'k' };
		testSeq = new Sequence(testChar);
		assertArrayEquals(testChar, testSeq.getSeq());
	}

	/**
	 * tests the toString method
	 */
	@Test
	public void toStringTest() {
		testString = "lmnop";
		testSeq = new Sequence(testString.toCharArray());
		assertEquals(testString, testSeq.toString());
	}

}
	