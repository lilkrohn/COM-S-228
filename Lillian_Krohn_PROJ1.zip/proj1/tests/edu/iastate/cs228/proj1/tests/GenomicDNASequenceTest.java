package edu.iastate.cs228.proj1.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.runners.MethodSorters;

import edu.iastate.cs228.proj1.Sequence;
import edu.iastate.cs228.proj1.GenomicDNASequence;

import org.junit.FixMethodOrder;

/**
 * @author Lillian Krohn
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class GenomicDNASequenceTest {

	String testString;
	GenomicDNASequence testGenSeq;

	/**
	 * checks that the exception is thrown
	 */
	@Test(expected = IllegalArgumentException.class)
	public void InvalidSequenceTest() {
		String probst3 = new String("TGCH");
		Sequence gdnaobj = new GenomicDNASequence(probst3.toCharArray());
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest() {
		assertEquals(testString, testGenSeq);
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest2() {
		testString = "atgtagat";
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		assertEquals(false, testGenSeq.equals(testString));
	}

	/**
	 * tests for a valid letter
	 */
	@Test
	public void isValidLetterTest() {
		testString = "atgatgatg";
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		assertEquals(true, testGenSeq.isValidLetter('g'));

	}

	/**
	 * tests for an invalid letter
	 */
	@Test
	public void isValidLetterTest2() {
		testString = "atgatgggat";
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		assertEquals(false, testGenSeq.isValidLetter('$'));
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest() {
		char[] testChar = { 'a', 't', 'g', 't' };
		testGenSeq = new GenomicDNASequence(testChar);
		assertEquals(4, testGenSeq.seqLength());
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest2() {
		char[] testChar = { 'a', 't', 'g', 'a' };
		testGenSeq = new GenomicDNASequence(testChar);
		assertArrayEquals(testChar, testGenSeq.getSeq());
	}

	/**
	 * tests the toString method
	 */
	@Test
	public void toStringTest() {
		testString = "atgggtat";
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		assertEquals(testString, testGenSeq.toString());
	}

	/**
	 * tests the exons method
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest() {
		testString = "gtcgat";
		int[] exons = { 1, 2, 3 };
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		testGenSeq.extractExons(exons);
	}

	/**
	 * tests the exons method
	 */
	@Test(expected = IllegalArgumentException.class)
	public void extractExonsTest2() {
		testString = "tcgtagt";
		int[] exons = { 4, 3, 5, 9 };
		testGenSeq = new GenomicDNASequence(testString.toCharArray());
		testGenSeq.extractExons(exons);
	}
}
