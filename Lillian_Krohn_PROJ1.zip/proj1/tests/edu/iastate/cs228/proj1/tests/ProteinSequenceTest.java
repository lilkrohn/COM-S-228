package edu.iastate.cs228.proj1.tests;

import org.junit.Test;
import static org.junit.Assert.*;

import org.junit.runners.MethodSorters;
import edu.iastate.cs228.proj1.Sequence;
import edu.iastate.cs228.proj1.ProteinSequence;

import org.junit.FixMethodOrder;

/**
 * @author Lillian Krohn
 */

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProteinSequenceTest {

	String testString;
	ProteinSequence testProSeq;
	char[] testSeqVals = { 'x', 'y', 'z' };

	/**
	 * checks that the exception is thrown
	 */
	@Test(expected = IllegalArgumentException.class)
	public void InvalidSequenceTest() {
		String probst4 = new String("BJU");
		ProteinSequence probj = new ProteinSequence(probst4.toCharArray());
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest() {
		assertEquals(testString, testProSeq);
	}

	/**
	 * tests the equals method
	 */
	@Test
	public void EqualsTest2() {
		testString = "eeyksdff";
		testProSeq = new ProteinSequence(testString.toCharArray());
		assertEquals(false, testProSeq.equals(testString));
	}

	/**
	 * tests for a valid letter
	 */
	@Test
	public void isValidLetterTest() {
		testString = "eysksdf";
		testProSeq = new ProteinSequence(testString.toCharArray());
		assertEquals(true, testProSeq.isValidLetter('f'));

	}

	/**
	 * tests for an invalid letter
	 */
	@Test
	public void isValidLetterTest2() {
		testString = "eyskhriy";
		testProSeq = new ProteinSequence(testString.toCharArray());
		assertEquals(false, testProSeq.isValidLetter('$'));
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest() {
		char[] testChar = { 'e', 'k', 'r', 'p' };
		testProSeq = new ProteinSequence(testChar);
		assertEquals(4, testProSeq.seqLength());
	}

	/**
	 * tests the getSeq method
	 */
	@Test
	public void getSeqTest2() {
		char[] testChar = { 'e', 'y', 'r', 'c' };
		testProSeq = new ProteinSequence(testChar);
		assertArrayEquals(testChar, testProSeq.getSeq());
	}

	/**
	 * tests the toString method
	 */
	@Test
	public void toStringTest() {
		testString = "eyrlkcd";
		testProSeq = new ProteinSequence(testString.toCharArray());
		assertEquals(testString, testProSeq.toString());
	}

}
